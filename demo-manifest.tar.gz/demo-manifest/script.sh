#!/bin/bash


echo "Setting up Datadog RBAC Rules"
kubectl apply -f rbac/clusterrole.yaml 
kubectl apply -f rbac/serviceaccount.yaml 
kubectl apply -f rbac/clusterrolebinding.yaml

echo "Deploying the Datadog Agent"
kubectl apply -f rbac/datadog_configmap.yam 
kubectl apply -f datadog-api-secret.yaml 
kubectl apply -f datadogagent.yaml

echo "Creating role for Kube State Metrics"
kubectl create clusterrolebinding cluster-admin-binding --clusterrole=cluster-admin --user=$(gcloud info --format='value(config.account)')

echo "Deploying Kube State Metrics"
kubectl apply -f kube-state-metrics/kubernetes

echo "Deploying redis master"
kubectl apply -f redis-master-deployment.yaml
kubectl apply -f redis-master-service.yaml

echo "Deploying frontend"
kubectl apply -f frontend-deployment.yaml
kubectl apply -f frontend-service.yaml

echo "Deploying redis slave"
kubectl apply -f redis-slave-deployment.yaml
kubectl apply -f redis-slave-service.yaml
